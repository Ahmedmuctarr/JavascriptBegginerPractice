let redlight = document.querySelector('.red');
let greenlight = document.querySelector('.green');
let yellowlight = document.querySelector('.yellow');
/*
redligth.style.backgroundColor = 'red';
greenlight.style.backgroundColor = 'green';
yellowlight.style.backgroundColor = 'yellow';
*/
let [timer,blink,warning] = [null,0,null];
function lights() {
    blink++;
    console.log(blink);
    

    if (blink <= 10) {
        
        yellowlight.style.backgroundColor = '#CAF4FF';
        redlight.style.backgroundColor = '#CAF4FF';
        greenlight.style.backgroundColor = 'green';
    } else if (blink <= 15) {
        // Toggle yellow light every second
        warning = setTimeout(() => {
            yellowlight.style.backgroundColor = yellowlight.style.backgroundColor === 'yellow' ? '#CAF4FF' : 'yellow';
        }, 1000);
        greenlight.style.backgroundColor = '#CAF4FF';
        redlight.style.backgroundColor = '#CAF4FF';
    } else if (blink <=20) {
        // Clear previous intervals if any
        clearTimeout(warning);
        warning = null;
        redlight.style.backgroundColor = 'red';
        yellowlight.style.backgroundColor = '#CAF4FF';
        greenlight.style.backgroundColor = '#CAF4FF';
    } else {
        blink = 0; // Reset blink counter
        // Optionally, reset all lights here
        greenlight.style.backgroundColor = '#green';
        yellowlight.style.backgroundColor = '#CAF4FF';
        redlight.style.backgroundColor = '#CAF4FF';
    }
}

timer = setInterval(lights, 1000);
//lights();